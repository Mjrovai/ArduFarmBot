
//ThingSpeak Settings 
#define IP "184.106.153.149"// thingspeak.com ip

String msg = "GET /update?key=99999999999999999999999"; //key to send data to channel 999999 (ArduFarmBot)

String msgReadLastDataField7 = "GET /channels/999999/fields/7/last"; // "GET /channels/CHANNEL_ID/fields/7/last"
String msgReadLastDataField8 = "GET /channels/999999/fields/8/last"; // "GET /channels/CHANNEL_ID/fields/8/last"


